# attack_requantize.py

import numpy as np
import scipy.io.wavfile as wav
import argparse

# =========================
# ARGUMENTS
# =========================
parser = argparse.ArgumentParser()

parser.add_argument("-i", "--input", required=True,
                    help="Input WAV")

parser.add_argument("-o", "--output", required=True,
                    help="Output attacked WAV")

args = parser.parse_args()

# =========================
# READ AUDIO
# =========================
rate, audio = wav.read(args.input)

audio = audio.astype(np.float64)

# =========================
# 16-bit -> 8-bit
# =========================
audio_8bit = (
    (audio + 32768) / 256
).astype(np.uint8)

# =========================
# 8-bit -> 16-bit
# =========================
restored = (
    audio_8bit.astype(np.int16) * 256
) - 32768

restored = np.clip(
    restored,
    -32768,
    32767
)

restored = restored.astype(np.int16)

# =========================
# SAVE
# =========================
wav.write(args.output,
          rate,
          restored)

print("[+] Requantization attack applied")
print("[+] 16-bit -> 8-bit -> 16-bit")
