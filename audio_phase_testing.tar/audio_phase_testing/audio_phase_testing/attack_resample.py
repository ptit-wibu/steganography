# attack_resample.py

import scipy.io.wavfile as wav
from scipy.signal import resample
import numpy as np
import argparse

# =========================
# ARGUMENTS
# =========================
parser = argparse.ArgumentParser()

parser.add_argument("-i", "--input", required=True,
                    help="Input WAV")

parser.add_argument("-o", "--output", required=True,
                    help="Output attacked WAV")

parser.add_argument("-r", "--rate",
                    type=int,
                    default=22050,
                    help="Temporary sample rate")

args = parser.parse_args()

# =========================
# READ AUDIO
# =========================
orig_rate, audio = wav.read(args.input)

audio = audio.astype(np.float64)

# =========================
# DOWN SAMPLE
# =========================
new_length = int(
    len(audio) * args.rate / orig_rate
)

down = resample(audio, new_length)

# =========================
# UP SAMPLE BACK
# =========================
restored = resample(
    down,
    len(audio)
)

restored = np.clip(
    restored,
    -32768,
    32767
)

restored = restored.astype(np.int16)

# =========================
# SAVE
# =========================
wav.write(args.output,
          orig_rate,
          restored)

print("[+] Resample attack applied")
print(f"[+] Temp sample rate: {args.rate}")
