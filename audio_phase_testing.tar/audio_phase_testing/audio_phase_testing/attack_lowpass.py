# attack_lowpass.py

import numpy as np
import scipy.io.wavfile as wav
from scipy.signal import butter, filtfilt
import argparse

# =========================
# ARGUMENTS
# =========================
parser = argparse.ArgumentParser()

parser.add_argument("-i", "--input", required=True)
parser.add_argument("-o", "--output", required=True)
parser.add_argument("-c", "--cutoff", type=int,
                    default=4000)

args = parser.parse_args()

# =========================
# READ AUDIO
# =========================
rate, audio = wav.read(args.input)

audio = audio.astype(np.float64)

# =========================
# LOWPASS FILTER
# =========================
nyquist = rate / 2

normal_cutoff = args.cutoff / nyquist

b, a = butter(6, normal_cutoff,
              btype='low')

filtered = filtfilt(b, a, audio)

filtered = np.clip(filtered,
                   -32768,
                   32767)

filtered = filtered.astype(np.int16)

# =========================
# SAVE
# =========================
wav.write(args.output, rate, filtered)

print("[+] Low-pass filter applied")
print(f"[+] Cutoff frequency: {args.cutoff} Hz")
