# attack_crop.py

import numpy as np
import scipy.io.wavfile as wav
import argparse

# =========================
# ARGUMENTS
# =========================
parser = argparse.ArgumentParser()

parser.add_argument("-i", "--input", required=True)
parser.add_argument("-o", "--output", required=True)

parser.add_argument("-c", "--crop",
                    type=float,
                    default=0.1,
                    help="Crop ratio")

args = parser.parse_args()

# =========================
# READ AUDIO
# =========================
rate, audio = wav.read(args.input)

crop_samples = int(len(audio) * args.crop)

cropped = audio[crop_samples:]

wav.write(args.output, rate, cropped)

print("[+] Crop attack applied")
print(f"[+] Cropped: {args.crop*100}%")
