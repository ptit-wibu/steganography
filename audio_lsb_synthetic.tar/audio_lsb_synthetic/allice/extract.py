#!/usr/bin/env python3
import wave
import argparse
import hashlib

END_MARKER = "###END###"

def bits_to_text(bits):
    chars = []
    for i in range(0, len(bits), 8):
        byte = ''.join(bits[i:i+8])
        if len(byte) < 8:
            continue
        chars.append(chr(int(byte, 2)))
    return ''.join(chars)

def get_positions(key, length, max_index):
    positions = []
    for i in range(length):
        h = hashlib.sha256((key + str(i)).encode()).hexdigest()
        pos = int(h, 16) % max_index
        positions.append(pos)
    return positions

def extract_1bit(frames):
    return [str(frames[i] & 1) for i in range(len(frames))]

def extract_4bit(frames):
    bits = []
    for i in range(len(frames)):
        value = frames[i] & 15
        bits.extend(list(format(value, '04b')))
    return bits

def extract_hash(frames, key):
    bits = []
    used = set()
    max_len = len(frames)

    for i in range(max_len):
        h = hashlib.sha256((key + str(i)).encode()).hexdigest()
        pos = int(h, 16) % max_len

        while pos in used:
            pos = (pos + 1) % max_len
        used.add(pos)

        bits.append(str(frames[pos] & 1))

        
        if len(bits) % 8 == 0:
            text = bits_to_text(bits)
            if END_MARKER in text:
                return bits

    return bits

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", required=True, choices=["1bit", "4bit", "hash"])
    parser.add_argument("stego_wav")
    parser.add_argument("--key", default="secretkey")

    args = parser.parse_args()

    with wave.open(args.stego_wav, 'rb') as f:
        frames = bytearray(f.readframes(f.getnframes()))

    if args.mode == "1bit":
        bits = extract_1bit(frames)
    elif args.mode == "4bit":
        bits = extract_4bit(frames)
    elif args.mode == "hash":
        bits = extract_hash(frames, args.key)

    message = bits_to_text(bits)

    if END_MARKER in message:
        message = message.split(END_MARKER)[0]

    print(message)

if __name__ == "__main__":
    main()
