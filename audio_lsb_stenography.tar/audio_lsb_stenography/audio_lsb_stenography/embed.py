#!/usr/bin/env python3
import wave
import argparse
import hashlib

END_MARKER = "###END###"

def text_to_bits(text):
    return ''.join(format(ord(c), '08b') for c in text)

def get_positions(key, length, max_index):
    positions = []
    for i in range(length):
        h = hashlib.sha256((key + str(i)).encode()).hexdigest()
        pos = int(h, 16) % max_index
        positions.append(pos)
    return positions

def embed_1bit(frames, bits):
    for i in range(len(bits)):
        frames[i] = (frames[i] & 254) | int(bits[i])
    return frames

def embed_4bit(frames, bits):
    for i in range(0, len(bits), 4):
        chunk = bits[i:i+4].ljust(4, '0')
        value = int(chunk, 2)
        frames[i//4] = (frames[i//4] & 240) | value
    return frames

def embed_hash(frames, bits, key):
    positions = get_positions(key, len(bits), len(frames))
    used = set()

    for i, pos in enumerate(positions):
        while pos in used:
            pos = (pos + 1) % len(frames)
        used.add(pos)

        frames[pos] = (frames[pos] & 254) | int(bits[i])
    return frames

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", required=True, choices=["1bit", "4bit", "hash"])
    parser.add_argument("input_wav")
    parser.add_argument("secret_file")
    parser.add_argument("output_wav")
    parser.add_argument("--key", default="secretkey")

    args = parser.parse_args()

    with wave.open(args.input_wav, 'rb') as f:
        params = f.getparams()
        frames = bytearray(f.readframes(f.getnframes()))

    with open(args.secret_file, 'r') as f:
        message = f.read()

    message += END_MARKER
    bits = text_to_bits(message)

    capacity = len(frames)
    if args.mode == "4bit":
        capacity *= 4

    if len(bits) > capacity:
        print("[!] Message too large!")
        return

    if args.mode == "1bit":
        frames = embed_1bit(frames, bits)
    elif args.mode == "4bit":
        frames = embed_4bit(frames, bits)
    elif args.mode == "hash":
        frames = embed_hash(frames, bits, args.key)

    with wave.open(args.output_wav, 'wb') as f:
        f.setparams(params)
        f.writeframes(frames)

    print("[+] Embedding completed!")

if __name__ == "__main__":
    main()
