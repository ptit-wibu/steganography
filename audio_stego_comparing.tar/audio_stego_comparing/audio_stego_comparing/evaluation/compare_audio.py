import numpy as np
import scipy.io.wavfile as wav
import argparse

# =========================
# ARGUMENTS
# =========================
parser = argparse.ArgumentParser()

parser.add_argument(
    "-o", "--original",
    required=True,
    help="Original WAV"
)

parser.add_argument(
    "-s", "--stego",
    required=True,
    help="Stego/Recovered WAV"
)

args = parser.parse_args()

# =========================
# READ AUDIO
# =========================
rate1, audio1 = wav.read(args.original)
rate2, audio2 = wav.read(args.stego)

audio1 = audio1.astype(np.float64)
audio2 = audio2.astype(np.float64)

# mono only
if audio1.ndim > 1:
    audio1 = audio1[:, 0]

if audio2.ndim > 1:
    audio2 = audio2[:, 0]

# =========================
# ALIGN LENGTH
# =========================
min_len = min(len(audio1), len(audio2))

audio1 = audio1[:min_len]
audio2 = audio2[:min_len]

# =========================
# METRICS
# =========================
difference = audio1 - audio2

mae = np.mean(np.abs(difference))

mse = np.mean(difference ** 2)

signal_power = np.mean(audio1 ** 2)

noise_power = np.mean(difference ** 2)

# avoid divide-by-zero
if noise_power == 0:
    snr = float('inf')
else:
    snr = 10 * np.log10(signal_power / noise_power)

# PSNR
max_possible = 32767

if mse == 0:
    psnr = float('inf')
else:
    psnr = 20 * np.log10(max_possible / np.sqrt(mse))

# =========================
# RESULTS
# =========================
print(f"[+] MAE  : {mae}")

print(f"[+] MSE  : {mse}")

print(f"[+] SNR  : {snr:.2f} dB")

print(f"[+] PSNR : {psnr:.2f} dB")

# =========================
# QUALITY ESTIMATION
# =========================
if snr > 30:
    print("[+] Excellent imperceptibility")

elif snr > 20:
    print("[+] Good imperceptibility")

elif snr > 10:
    print("[+] Moderate distortion")

else:
    print("[-] Distortion noticeable")
