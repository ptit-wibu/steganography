# calculate_ber.py

import argparse
import subprocess

# =========================
# ARGUMENTS
# =========================
parser = argparse.ArgumentParser()

parser.add_argument(
    "-s", "--secret",
    required=True,
    help="Original secret file"
)

parser.add_argument(
    "-i", "--input",
    required=True,
    help="Attacked WAV file"
)

parser.add_argument(
    "-m", "--msglen",
    required=True,
    type=int,
    help="Message length"
)

args = parser.parse_args()

# =========================
# READ ORIGINAL MESSAGE
# =========================
with open(args.secret, "r") as f:
    original = f.read().strip()

# =========================
# RUN EXTRACTOR
# =========================
result = subprocess.check_output([
    "python3",
    "extract.py",
    "--mode", "1bit",
    args.input
]).decode(errors="ignore")

# =========================
# CLEAN OUTPUT
# =========================
lines = result.splitlines()

recovered = ""

for line in lines:

    line = line.strip()

    # bỏ log
    if line.startswith("[+]"):
        continue

    if line != "":
        recovered = line
        break

# =========================
# CẮT ĐÚNG ĐỘ DÀI MESSAGE
# =========================
recovered = recovered[:args.msglen]

# =========================
# STRING -> BINARY
# =========================
orig_bits = ''.join(
    format(ord(c), '08b')
    for c in original
)

recv_bits = ''.join(
    format(ord(c), '08b')
    for c in recovered
)

# =========================
# ALIGN LENGTH
# =========================
min_len = min(
    len(orig_bits),
    len(recv_bits)
)

orig_bits = orig_bits[:min_len]
recv_bits = recv_bits[:min_len]

# =========================
# CALCULATE BER
# =========================
errors = sum(
    b1 != b2
    for b1, b2 in zip(orig_bits, recv_bits)
)

if min_len > 0:
    ber = errors / min_len
else:
    ber = 1

# =========================
# PRINT RESULTS
# =========================
print(f"[+] Original : {repr(original)}")
print(f"[+] Recovered: {repr(recovered)}")

print(f"[+] Total bits : {min_len}")
print(f"[+] Bit errors : {errors}")
print(f"[+] BER        : {ber:.6f}")

# =========================
# QUALITY
# =========================
if ber == 0:

    print("[+] Perfect recovery")

elif ber < 0.1:

    print("[+] Minor corruption")

else:

    print("[-] Message heavily corrupted")
