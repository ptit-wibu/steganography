#!/usr/bin/env python3

import wave
import argparse

# =========================
# TEXT -> BITS
# =========================
def text_to_bits(text):

    bits = []

    for c in text:
        bits.extend(format(ord(c), '08b'))

    return bits


# =========================
# MAIN
# =========================
def main():

    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--mode",
        required=True,
        choices=["1bit"]
    )

    parser.add_argument("cover_wav")

    parser.add_argument("secret_file")

    parser.add_argument("output_wav")

    args = parser.parse_args()

    # =========================
    # READ SECRET
    # =========================
    with open(args.secret_file, "r") as f:
        secret = f.read()

    # =========================
    # MESSAGE LENGTH
    # =========================
    msg_len = len(secret)

    # 16-bit header
    header_bits = format(msg_len, '016b')

    # message bits
    msg_bits = ''.join(text_to_bits(secret))

    full_bits = header_bits + msg_bits

    # =========================
    # READ AUDIO
    # =========================
    with wave.open(args.cover_wav, 'rb') as song:

        params = song.getparams()

        frames = bytearray(
            song.readframes(song.getnframes())
        )

    # =========================
    # CAPACITY CHECK
    # =========================
    if len(full_bits) > len(frames):

        raise ValueError(
            "Message too large"
        )

    # =========================
    # EMBED
    # =========================
    for i, bit in enumerate(full_bits):

        frames[i] = (
            frames[i] & 254
        ) | int(bit)

    # =========================
    # WRITE OUTPUT
    # =========================
    with wave.open(args.output_wav, 'wb') as out:

        out.setparams(params)

        out.writeframes(frames)

    print("[+] Embedding complete")
    print(f"[+] Message length: {msg_len} chars")


if __name__ == "__main__":
    main()
