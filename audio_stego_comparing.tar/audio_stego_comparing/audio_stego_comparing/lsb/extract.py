#!/usr/bin/env python3

import wave
import argparse

# =========================
# BITS -> TEXT
# =========================
def bits_to_text(bits):

    chars = []

    for i in range(0, len(bits), 8):

        byte = ''.join(bits[i:i+8])

        chars.append(
            chr(int(byte, 2))
        )

    return ''.join(chars)


# =========================
# MAIN
# =========================
def main():

    parser = argparse.ArgumentParser()

    parser.add_argument(
        "--mode",
        required=True,
        choices=["1bit"]
    )

    parser.add_argument("stego_wav")

    args = parser.parse_args()

    # =========================
    # READ AUDIO
    # =========================
    with wave.open(args.stego_wav, 'rb') as song:

        frames = bytearray(
            song.readframes(song.getnframes())
        )

    # =========================
    # EXTRACT HEADER
    # =========================
    header_bits = []

    for i in range(16):

        header_bits.append(
            str(frames[i] & 1)
        )

    msg_len = int(
        ''.join(header_bits),
        2
    )

    print(f"[+] Expected length: {msg_len} chars")

    # =========================
    # EXTRACT MESSAGE
    # =========================
    msg_bits = []

    total_bits = msg_len * 8

    for i in range(16, 16 + total_bits):

        msg_bits.append(
            str(frames[i] & 1)
        )

    # =========================
    # CONVERT
    # =========================
    message = bits_to_text(msg_bits)

    print("\n[+] MESSAGE:")
    print(message)


if __name__ == "__main__":
    main()
