import numpy as np
import scipy.io.wavfile as wav
import argparse

# =========================
# ARGUMENTS
# =========================
parser = argparse.ArgumentParser()

parser.add_argument(
    "-i", "--input",
    required=True,
    help="Input WAV file"
)

parser.add_argument(
    "-m", "--message",
    required=True,
    help="Secret message file"
)

args = parser.parse_args()

# =========================
# READ AUDIO
# =========================
rate, audio = wav.read(args.input)

# mono only
if audio.ndim > 1:
    audio = audio[:, 0]

audio_len = len(audio)

# =========================
# READ MESSAGE
# =========================
with open(args.message, "r") as f:
    msg = f.read()

msg_chars = len(msg)

msg_bits = msg_chars * 8

# =========================
# LSB CAPACITY
# =========================
# 1 sample = 1 bit hidden
max_bits = audio_len

max_chars = max_bits // 8

usage = (msg_bits / max_bits) * 100

# =========================
# RESULTS
# =========================
print("\n========== LSB CAPACITY ANALYSIS ==========\n")

print(f"[+] Audio samples            : {audio_len}")

print(f"[+] Message characters       : {msg_chars}")

print(f"[+] Message bits             : {msg_bits}")

print(f"[+] Maximum embeddable bits  : {max_bits}")

print(f"[+] Maximum characters       : {max_chars}")

print(f"[+] Capacity usage           : {usage:.6f}%")

print("\n===========================================\n")

# =========================
# QUALITY ESTIMATION
# =========================
if usage < 10:

    print("[+] Very low distortion expected")

elif usage < 50:

    print("[+] Moderate distortion expected")

else:

    print("[-] High distortion may occur")
