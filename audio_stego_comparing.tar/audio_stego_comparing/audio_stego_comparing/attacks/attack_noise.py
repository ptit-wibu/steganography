# attack_noise.py

import numpy as np
import scipy.io.wavfile as wav
import argparse

# =========================
# ARGUMENTS
# =========================
parser = argparse.ArgumentParser()

parser.add_argument("-i", "--input", required=True,
                    help="Input stego WAV")

parser.add_argument("-o", "--output", required=True,
                    help="Output attacked WAV")

parser.add_argument("-n", "--noise", type=float,
                    default=0.05,
                    help="Noise strength")

args = parser.parse_args()

# =========================
# READ AUDIO
# =========================
rate, audio = wav.read(args.input)

audio = audio.astype(np.float64)

# =========================
# GENERATE NOISE
# =========================
noise = np.random.normal(
    0,
    args.noise * np.max(np.abs(audio)),
    audio.shape
)

attacked = audio + noise

# =========================
# CLIP
# =========================
attacked = np.clip(attacked, -32768, 32767)

attacked = attacked.astype(np.int16)

# =========================
# SAVE
# =========================
wav.write(args.output, rate, attacked)

print("[+] Noise attack applied")
print(f"[+] Noise strength: {args.noise}")
