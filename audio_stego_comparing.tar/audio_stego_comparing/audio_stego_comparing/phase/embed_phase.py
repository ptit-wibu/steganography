import numpy as np
import scipy.io.wavfile as wav
import argparse

# =========================
# ARGUMENTS
# =========================
parser = argparse.ArgumentParser()

parser.add_argument("-i", "--input", required=True,
                    help="Input WAV file")

parser.add_argument("-m", "--message", required=True,
                    help="Secret message file")

parser.add_argument("-o", "--output", required=True,
                    help="Output stego WAV")

args = parser.parse_args()

# =========================
# READ AUDIO
# =========================
rate, audio = wav.read(args.input)

audio = audio.astype(np.float64)

# mono
if audio.ndim > 1:
    audio = audio[:, 0]

# =========================
# READ MESSAGE
# =========================
with open(args.message, "r") as f:
    msg = f.read()

msglen = 8 * len(msg)

# string -> binary
msgbin = np.array([
    int(bit)
    for ch in msg
    for bit in format(ord(ch), '08b')
])

# 0 => +pi/2
# 1 => -pi/2
msgPi = np.where(msgbin == 0,
                 np.pi / 2,
                 -np.pi / 2)

# =========================
# SEGMENT SIZE
# =========================
seglen = int(
    2 * 2 ** np.ceil(np.log2(2 * msglen))
)

segnum = int(
    np.ceil(len(audio) / seglen)
)

# pad audio
audio = np.pad(
    audio,
    (0, segnum * seglen - len(audio))
)

# =========================
# SPLIT SEGMENTS
# =========================
segments = audio.reshape(segnum, seglen)

# =========================
# FFT
# =========================
spectrum = np.fft.fft(segments)

M = np.abs(spectrum)
P = np.angle(spectrum)

# =========================
# PHASE DIFFERENCE
# =========================
dP = np.diff(P, axis=0)

mid = seglen // 2

# =========================
# EMBED MESSAGE
# =========================
P[0, mid-msglen:mid] = msgPi

# Hermitian symmetry
P[0, mid+1:mid+1+msglen] = -msgPi[::-1]

# =========================
# REBUILD PHASES
# =========================
for i in range(1, segnum):
    P[i] = P[i - 1] + dP[i - 1]

# =========================
# IFFT
# =========================
new_spectrum = M * np.exp(1j * P)

stego = np.fft.ifft(new_spectrum).real

stego = stego.reshape(-1)

stego = np.int16(stego)

# =========================
# SAVE
# =========================
wav.write(args.output, rate, stego)

print("[+] EMBED DONE SUCCESSFULLY")

