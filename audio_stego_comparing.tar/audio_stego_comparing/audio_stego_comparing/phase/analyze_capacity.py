import numpy as np
import scipy.io.wavfile as wav
import argparse

# =========================
# ARGUMENTS
# =========================
parser = argparse.ArgumentParser()

parser.add_argument(
    "-i", "--input",
    required=True,
    help="Input WAV file"
)

parser.add_argument(
    "-m", "--message",
    required=True,
    help="Secret message file"
)

args = parser.parse_args()

# =========================
# READ AUDIO
# =========================
rate, audio = wav.read(args.input)

if audio.ndim > 1:
    audio = audio[:, 0]

audio_len = len(audio)

# =========================
# READ MESSAGE
# =========================
with open(args.message, "r") as f:
    msg = f.read()

msg_chars = len(msg)

msg_bits = msg_chars * 8

# =========================
# CALCULATE SEGMENT LENGTH
# =========================
seglen = int(
    2 * 2 ** np.ceil(np.log2(2 * msg_bits))
)

usable_phase_bins = seglen // 2

max_chars = usable_phase_bins // 8

usage = (msg_bits / usable_phase_bins) * 100

# =========================
# AUDIO SEGMENTS
# =========================
segnum = int(np.ceil(audio_len / seglen))

# =========================
# RESULTS
# =========================
print("\n========== CAPACITY ANALYSIS ==========\n")

print(f"[+] Audio samples            : {audio_len}")

print(f"[+] Message characters       : {msg_chars}")

print(f"[+] Message bits             : {msg_bits}")

print(f"[+] Required segment length  : {seglen}")

print(f"[+] Available phase bins     : {usable_phase_bins}")

print(f"[+] Maximum characters       : {max_chars}")

print(f"[+] Capacity usage           : {usage:.2f}%")

print(f"[+] Number of segments       : {segnum}")

print("\n=======================================\n")

# =========================
# QUALITY ESTIMATION
# =========================
if usage < 30:
    print("[+] Very low distortion expected")

elif usage < 60:
    print("[+] Moderate distortion expected")

else:
    print("[-] High distortion may occur")
