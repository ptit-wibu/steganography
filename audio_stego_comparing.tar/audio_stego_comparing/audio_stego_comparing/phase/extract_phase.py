import numpy as np
import scipy.io.wavfile as wav
import argparse

# =========================
# ARGUMENTS
# =========================
parser = argparse.ArgumentParser()

parser.add_argument("-i", "--input", required=True,
                    help="Stego WAV")

parser.add_argument("-m", "--msglen", required=True,
                    type=int,
                    help="Message length in characters")

args = parser.parse_args()

# =========================
# READ AUDIO
# =========================
rate, audio = wav.read(args.input)

audio = audio.astype(np.float64)

if audio.ndim > 1:
    audio = audio[:, 0]

# =========================
# SETTINGS
# =========================
msglen = args.msglen * 8

seglen = int(
    2 * 2 ** np.ceil(np.log2(2 * msglen))
)

mid = seglen // 2

# =========================
# FIRST SEGMENT
# =========================
segment = audio[:seglen]

# =========================
# FFT
# =========================
P = np.angle(
    np.fft.fft(segment)
)

# =========================
# EXTRACT BITS
# =========================
bits = (
    P[mid-msglen:mid] < 0
).astype(np.int8)

# =========================
# BITS -> TEXT
# =========================
chars = []

for i in range(0, len(bits), 8):

    byte = bits[i:i+8]

    value = 0

    for bit in byte:
        value = (value << 1) | bit

    chars.append(chr(value))

message = ''.join(chars)

print("[+] MESSAGE:", message)

